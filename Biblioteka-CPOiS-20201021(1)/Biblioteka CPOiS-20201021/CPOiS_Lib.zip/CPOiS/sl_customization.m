function sl_customization(cm)
% Change the order of libraries in the Simulink Library Browser. 
cm.LibraryBrowserCustomizer.applyOrder({'CPOiS - Digital image and signal processing',-2});
end